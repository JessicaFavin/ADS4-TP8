Pour lancer le projet, éxécutez les instructions suivantes :

jflex program.flex
javac *.java
java Main

Des fichiers tests sont présents dans l'archive (good et bad).
Et la grammaire est expliquée dans le fichier grammaire.txt et 
au début des fichiers Parser et ParserFile (ayant des grammaires 
légèrement différentes)
