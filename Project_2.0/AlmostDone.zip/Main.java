

/**
 *
 * @author Anthony CHAFFOT
 * @author Jessica FAVIN
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame frame = new Frame();
        
    }
    
}
