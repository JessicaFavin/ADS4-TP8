public enum Sym {
    LPAR,
    RPAR,
    LACC,
    RACC,
    INT,
    VARIABLE,
    PRINT,
    FOR,
    TIMESDO,
    VAR,
    EQ,
    CONCAT, 
    PLUS,
    MINUS,
    TIMES,
    DIV,
    EOF;  //token representinting the end of file
}
