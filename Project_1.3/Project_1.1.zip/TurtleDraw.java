

/**
 *
 * @author Anthony
 */
public class TurtleDraw {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame frame = new Frame();
        
    }
    
}
